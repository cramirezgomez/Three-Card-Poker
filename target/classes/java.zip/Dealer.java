import java.util.ArrayList;

public class Dealer {
	
	//Deck of the game 
	Deck theDeck;
	
	//Holds the dealers hand 
	ArrayList<Card> dealersHand;
	
	//Initializes the (deck) and the (dealers hand) 
	public Dealer(){
		
		theDeck = new Deck();
		dealersHand = new ArrayList<Card>();
		
	}
	
	//deal a hand of three cards
	public ArrayList<Card> dealHand(){
		
		//Store the 3 cards that are being taken from the deck
		ArrayList<Card> hand = new ArrayList<Card>();
		
		//To Do: Before each game starts the dealer must check there are > 34 cards in the deck 
		//If they are not then a new deck is to be constructed 
		if(theDeck.size() < 34)
		{
			theDeck = new Deck();
		}
		
		//Add cards (3) to the hand and remove cards (3) from the deck 
		for(int i = 0; i < 3; ++i) 
		{
			hand.add(theDeck.get(i));
			theDeck.remove(i);
		}
		
		//Return a hand of 3 cards 
		return hand;
	} 
	
	//To Do: Keep Track of the dealersHand (Have a use for it)
}
