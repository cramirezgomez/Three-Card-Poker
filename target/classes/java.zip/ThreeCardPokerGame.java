import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class ThreeCardPokerGame extends Application {

	Player playerOne;
	Player playerTwo;
	Dealer theDealer;
	
	private Button btnStart;
	private Button btnBet;
	private Button btnPlay;
	private Button btnPlayAgain;
	private Label txt1;
	private MenuBar menubar;
	private Menu mOne;
	private BorderPane border;
	private VBox startBox;
	
	private Scene scene0, scene1, scene2, scene3;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

	
	
	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		primaryStage.setTitle("Let's Play Three Card Poker!!!");
		menubar = new MenuBar();
		Menu mOne = new Menu("Options");
		
		
		
		
		//Start Scene setup
		border = new BorderPane();
		btnStart = new Button("Start");
		txt1 = new Label("Press Start to Play");
		startBox = new VBox(20, txt1, btnStart);
		startBox.setAlignment(Pos.CENTER);
		border.setCenter(startBox);
		btnStart.setOnAction(e->primaryStage.setScene(scene1));
		scene0 = new Scene(border, 600, 600);
		
		//Bet Scene setup
		border = new BorderPane();
		btnBet = new Button("Bet");
		border.setCenter(btnBet);
		scene1 = new Scene(border, 600, 600);
		btnBet.setOnAction(e->primaryStage.setScene(scene2));
		
		//Fold/Play Scene
		border = new BorderPane();
		btnPlay = new Button("Play");
		border.setCenter(btnPlay);
		scene2 = new Scene(border, 600, 600);
		btnPlay.setOnAction(e->primaryStage.setScene(scene3));
		
		//Results
		border = new BorderPane();
		btnPlayAgain = new Button("Results");
		border.setCenter(btnPlayAgain);
		scene3 = new Scene(border, 600, 600);
		btnPlayAgain.setOnAction(e->primaryStage.setScene(scene0));
		
		
		primaryStage.setScene(scene0);
		primaryStage.show();
	}

}
