import java.util.ArrayList;

public class Player {
	
	//Player Variables
	ArrayList<Card> hand;
	int anteBet;
	int playBet;
	int pairPlusBet;
	int totalWinnings;
	
	//set variables to 0
	//Default constructor of player 
	Player(){
		hand = new ArrayList<Card>();
		anteBet = 0;
		playBet = 0;
		pairPlusBet = 0;
		totalWinnings = 0;
	}
}
